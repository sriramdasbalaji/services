﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.Models
{
    public class WorkItemslinkedToBuild
    {
        public class Value
        {
            public string id { get; set; }
            public string url { get; set; }
        }

        public class LinkedWITs
        {
            public int count { get; set; }
            public List<Value> value { get; set; }
        }
    }
}