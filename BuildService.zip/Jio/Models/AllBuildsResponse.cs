﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.Models
{
    public class AllBuildsResponse
    {
        public class Definition
        {
            public int id { get; set; }
            public string name { get; set; }
            public string url { get; set; }
            public string uri { get; set; }
            public string path { get; set; }
            public string type { get; set; }
        }

        public class Project
        {
            public string id { get; set; }
            public string name { get; set; }
            public string url { get; set; }
            public string state { get; set; }
            public int revision { get; set; }
            public string visibility { get; set; }
        }

        public class Value
        {
            public int id { get; set; }
            public string buildNumber { get; set; }
            public string status { get; set; }
            public string result { get; set; }
            public string url { get; set; }
            public Definition definition { get; set; }
            public Project project { get; set; }
            public string uri { get; set; }
        }

        public class AllBuilds
        {
            public int count { get; set; }
            public List<Value> value { get; set; }
        }
    }
}