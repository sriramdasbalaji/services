﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
namespace JioServices.Models
{
    public class WorkItemResponse
    {
        public class Fields
        {
            [JsonProperty(PropertyName = "System.Id")]
            public int WorkItemId { get; set; }
        }

        public class Attributes
        {
            public string name { get; set; }
            public int? id { get; set; }
            public string comment { get; set; }
        }

        public class Relation
        {
            public string rel { get; set; }
            public string url { get; set; }
            public Attributes attributes { get; set; }
        }

        public class WorkItem
        {
            public int id { get; set; }
            public int rev { get; set; }
            public Fields fields { get; set; }
            public IList<Relation> relations { get; set; }
        }
    }
}