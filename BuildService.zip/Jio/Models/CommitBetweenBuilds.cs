﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.Models
{
    public class CommitBetweenBuilds
    {
        public class Value
        {
            public string id { get; set; }
            public string message { get; set; }
            public string type { get; set; }
        }

        public class Commits
        {
            public int count { get; set; }
            public List<Value> value { get; set; }
        }
    }
}