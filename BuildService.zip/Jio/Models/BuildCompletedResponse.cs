﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.Models
{
    public class BuildCompletedResponse
    {
        public class Definition
        {
            public int id { get; set; }
            public string name { get; set; }
            public string url { get; set; }
        }
        public class Resource
        {
            public string uri { get; set; }
            public int id { get; set; }
            public string buildNumber { get; set; }
            public string url { get; set; }
            public string reason { get; set; }
            public string status { get; set; }
            public Definition definition { get; set; }
        }

        public class Collection
        {
            public string id { get; set; }
            public string baseUrl { get; set; }
        }

        public class Server
        {
            public string id { get; set; }
            public string baseUrl { get; set; }
        }

        public class Project
        {
            public string id { get; set; }
            public string baseUrl { get; set; }
        }

        public class ResourceContainers
        {
            public Collection collection { get; set; }
            public Server server { get; set; }
            public Project project { get; set; }
        }

        public class Build
        {
            public string eventType { get; set; }
            public string publisherId { get; set; }
            public Resource resource { get; set; }
            public ResourceContainers resourceContainers { get; set; }
        }
    }
}