﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.ServiceInterfaces
{
    public interface IAppConfiguration
    {
        string APIVersion { get; set; }
        string CollectionName { get; set; }
        string AuthenticationType { get; set; }
        string BaseURL { get; set; }
        string ProjectName { get; set; }
        string Token { get; set; }
        string API { get; set; }
    }
}