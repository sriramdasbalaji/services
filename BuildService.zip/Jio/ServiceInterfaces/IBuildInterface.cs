﻿using JioServices.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace JioServices.ServiceInterfaces
{
    public interface IBuildInterface
    {
        HttpResponseMessage GetAllBuilds(string api, AppConfiguration appConfiguration);
        HttpResponseMessage CompareBuilds(string api, AppConfiguration appConfiguration);
        HttpResponseMessage GetCommitChangesBetweenBuilds(string api, AppConfiguration _buildConfiguration);
    }
}
