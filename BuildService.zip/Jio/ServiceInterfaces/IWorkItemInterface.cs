﻿using JioServices.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace JioServices.ServiceInterfaces
{
    public interface IWorkItemInterface
    {
        HttpResponseMessage GetWorkItemAssociatedToBuild(AppConfiguration _workItemConfiguration, int definitionId);
        HttpResponseMessage GetWotkItemDetailInBatch(string api, AppConfiguration _workItemConfiguration);
        HttpResponseMessage UpdateWorkItem(object[] witUpdate, AppConfiguration _workItemConfiguration, int WitId);
    }
}
