﻿using JioServices.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JioServices.Services
{
    public class AppConfiguration : IAppConfiguration
    {
        public string APIVersion { get; set; }
        public string CollectionName { get; set; }
        public string AuthenticationType { get; set; }
        public string BaseURL { get; set; }
        public string ProjectName { get; set; }
        public string Token { get; set; }
        public string API { get; set; }
    }
}