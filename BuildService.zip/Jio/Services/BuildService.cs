﻿using HttpRequestResponses;
using JioServices.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace JioServices.Services
{
    public class BuildService : IBuildInterface
    {
        private readonly IHttpRequestResponse _requestResponse;

        public BuildService(IHttpRequestResponse requestResponse)
        {
            _requestResponse = requestResponse;
        }

        public HttpResponseMessage CompareBuilds(string api, AppConfiguration _buildConfiguration)
        {
            HttpResponseMessage response = _requestResponse.Get(api, _buildConfiguration.AuthenticationType, _buildConfiguration.Token);
            return response;
        }

        public HttpResponseMessage GetAllBuilds(string api, AppConfiguration _buildConfiguration)
        {
            HttpResponseMessage response = _requestResponse.Get(api, _buildConfiguration.AuthenticationType, _buildConfiguration.Token);
            return response;
        }

        public HttpResponseMessage GetCommitChangesBetweenBuilds(string api, AppConfiguration _buildConfiguration)
        {
            HttpResponseMessage response = _requestResponse.Get(api, _buildConfiguration.AuthenticationType, _buildConfiguration.Token);
            return response;
        }
    }
}