﻿using HttpRequestResponses;
using JioServices.Models;
using JioServices.ServiceInterfaces;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;

namespace JioServices.Services
{
    public class WorkItemService : IWorkItemInterface
    {
        private IHttpRequestResponse _requestResponse;
        private IBuildInterface _build;
        public static ILog _logger = LogManager.GetLogger("ErrorLog");

        public WorkItemService(IHttpRequestResponse requestResponse, IBuildInterface buildInterface)
        {
            _requestResponse = requestResponse;
            _build = buildInterface;
        }
        // Getting the work items associated to build
        public HttpResponseMessage GetWorkItemAssociatedToBuild(AppConfiguration _workItemConfiguration, int definitionId)
        {
            try
            {
                HttpResponseMessage response = _requestResponse.Get(_workItemConfiguration.API, _workItemConfiguration.AuthenticationType, _workItemConfiguration.Token);
                return response;
            }
            catch (Exception ex)
            {
                _logger.Debug(ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }

        // Check the work item for the build link, if not exist call the update method to update WIT
        public HttpResponseMessage GetWotkItemDetailInBatch(string getDetailsApi, AppConfiguration _workItemConfiguration)
        {
            try
            {
                string reqApi = getDetailsApi + "?$expand=all&api-version=" + _workItemConfiguration.APIVersion;
                HttpResponseMessage response = _requestResponse.Get(reqApi, _workItemConfiguration.AuthenticationType, _workItemConfiguration.Token);
                return response;
            }
            catch (Exception ex)
            {
                _logger.Debug(ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }

        // Update the work item links
        public HttpResponseMessage UpdateWorkItem(object[] witUpdate, AppConfiguration _workItemConfiguration, int WitId)
        {
            try
            {
                string updateAPIRequest = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/wit/workitems/" + WitId + "?bypassRules=true&$expand=links&api-version=" + _workItemConfiguration.APIVersion;
                HttpResponseMessage response = _requestResponse.Patch(updateAPIRequest, witUpdate, _workItemConfiguration.AuthenticationType, _workItemConfiguration.Token);
                return response;

            }
            catch (Exception ex)
            {
                _logger.Debug(ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine);
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }
    }
}