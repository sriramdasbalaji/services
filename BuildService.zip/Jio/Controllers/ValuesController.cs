﻿using JioServices.Models;
using JioServices.ServiceInterfaces;
using JioServices.Services;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Hosting;
using System.Web.Http;

namespace JioServices.Controllers
{
    public class ValuesController : ApiController
    {
        private IBuildInterface _build;
        private IWorkItemInterface _workItem;
        private AppConfiguration _buildConfiguration;
        private AppConfiguration _workItemConfiguration;
        private string logPath = string.Empty;
        private string logFile = string.Empty;

        public static ILog _logger = LogManager.GetLogger("ErrorLog");
        public ValuesController(IBuildInterface build, IWorkItemInterface workItem)
        {
            _build = build;
            _workItem = workItem;

            string buildApiVersion = ConfigurationManager.AppSettings["BuildApiVersion"];
            string workitemApiVersion = ConfigurationManager.AppSettings["WorkItemApiVersion"];
            string token = ConfigurationManager.AppSettings["Token"];
            string authenticationType = ConfigurationManager.AppSettings["AuthenticationType"];

            _buildConfiguration = new AppConfiguration { APIVersion = buildApiVersion, Token = token, AuthenticationType = authenticationType };
            _workItemConfiguration = new AppConfiguration { APIVersion = workitemApiVersion, Token = token, AuthenticationType = authenticationType };
        }
        [HttpPost]
        [Route("api/buildcompleted")]
        public void BuildCompleted(object _Request)
        {
            try
            {
                string scheme = Request.Headers.Authorization != null ? Request.Headers.Authorization.Scheme : "Basic";
                //string pat = Request.Headers.Authorization != null ? Request.Headers.Authorization.Parameter : "";
                string pat = Request.Headers.Authorization.Parameter;
                //LogData(pat);
                //LogData(_Request.ToString());
                if (!string.IsNullOrEmpty(pat) && !string.IsNullOrEmpty(scheme))
                {
                    _workItemConfiguration.AuthenticationType = scheme;
                    _workItemConfiguration.Token = pat;

                    _buildConfiguration.AuthenticationType = scheme;
                    _buildConfiguration.Token = pat;
                    string req = _Request.ToString();
                    if (!string.IsNullOrEmpty(req))
                    {
                        BuildCompletedResponse.Build buildComplete = new BuildCompletedResponse.Build();
                        buildComplete = JsonConvert.DeserializeObject<BuildCompletedResponse.Build>(req);
                        string buildName = buildComplete.resource.definition.name;
                        int buildNumber = buildComplete.resource.id;
                        logPath = HostingEnvironment.MapPath("/logs/" + buildName);
                        logFile = HostingEnvironment.MapPath("/logs/" + buildName + "/" + DateTime.Now.ToString("yyyy-MM-dd") + "-BuildNumber -" + buildNumber + ".txt");

                        if (buildComplete.eventType == "build.complete") // Checking for event and status of the build. It won't be linked to work item if the build status is failed
                        {
                            LogData(buildComplete.eventType);
                            // FORMING RQEUEST API - to get the work items associated to build
                            _workItemConfiguration.BaseURL = buildComplete.resourceContainers.collection.baseUrl;
                            _workItemConfiguration.ProjectName = buildComplete.resourceContainers.project.id;

                            //GET https://{instance}/{collection}/{project}/_apis/build/builds/{buildId}/workitems?api-version=5.0

                            _workItemConfiguration.API = buildComplete.resourceContainers.collection.baseUrl + buildComplete.resourceContainers.project.id + "/_apis/build/builds/" + buildComplete.resource.id + "/workitems?api-version=" + _workItemConfiguration.APIVersion;
                            HttpResponseMessage workItemResponse = _workItem.GetWorkItemAssociatedToBuild(_workItemConfiguration, buildComplete.resource.definition.id); // Get work items associated to build
                            if (workItemResponse != null)
                            {
                                if (workItemResponse.IsSuccessStatusCode)
                                {
                                    string res = workItemResponse.Content.ReadAsStringAsync().Result;
                                    WorkItemslinkedToBuild.LinkedWITs linkedWITs = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(res); // linked WITS
                                    if (linkedWITs.count > 0)
                                    {
                                        LogData("work item count:" + linkedWITs.count);
                                        // if there is a work item linked to the incoming build
                                        foreach (var wit in linkedWITs.value)
                                        {
                                            // Get the work item details with all relations
                                            HttpResponseMessage _batchResponse = _workItem.GetWotkItemDetailInBatch(wit.url, _workItemConfiguration); // Getting WIT details in Batch
                                            if (_batchResponse.IsSuccessStatusCode)
                                            {
                                                string batchres = _batchResponse.Content.ReadAsStringAsync().Result;
                                                WorkItemResponse.WorkItem workItem = JsonConvert.DeserializeObject<WorkItemResponse.WorkItem>(batchres);
                                                //buildComplete.resource.uri

                                                FormatUpdateWorkItem(buildComplete.resource.uri, workItem);

                                            }
                                            else
                                            {
                                                string batchres = _batchResponse.ReasonPhrase + Environment.NewLine;
                                                LogData(batchres);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        // Get the builds associated to the definition

                                        // Get all builds 
                                        // GET https://dev.azure.com/{organization}/{project}/_apis/build/builds?definitions={definitionsID}&api-version=5.1
                                        // compare the builds and get the links
                                        string getAllBuildsAPI = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/builds?definitions=" + buildComplete.resource.definition.id + "&api-version=" + _buildConfiguration.APIVersion;
                                        HttpResponseMessage allBuilds = _build.GetAllBuilds(getAllBuildsAPI, _buildConfiguration);

                                        if (allBuilds.IsSuccessStatusCode)
                                        {
                                            string buildsRes = allBuilds.Content.ReadAsStringAsync().Result;
                                            AllBuildsResponse.AllBuilds builds = JsonConvert.DeserializeObject<AllBuildsResponse.AllBuilds>(buildsRes);
                                            if (builds.count > 0)
                                            {
                                                LogData("Build count:" + builds.count);
                                                bool isWorkItem = false;
                                                int fromBuildId = 0;
                                                int toBuildId = 0;
                                                List<string> buildResoureces = new List<string>();

                                                for (int b = 0; b < builds.count; b++)
                                                {
                                                    fromBuildId = builds.value[b].id;
                                                    if (builds.count > b + 1)
                                                    {
                                                        toBuildId = builds.value[b + 1].id;
                                                        LogData("Get the changes in commit");
                                                        // Get the changes in commit
                                                        string commitBetweenBuilds = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/changes?fromBuildId=" + fromBuildId + "&toBuildId=" + toBuildId + "&api-version=5.1-preview.2";
                                                        //https://dev.azure.com/devteamtests/JioServices/_apis/build/changes?fromBuildId=169&toBuildId=167&api-version=5.1-preview.2
                                                        HttpResponseMessage commitsBtwBuilds = _build.GetCommitChangesBetweenBuilds(commitBetweenBuilds, _buildConfiguration);
                                                        if (commitsBtwBuilds.IsSuccessStatusCode)
                                                        {
                                                            string commitsbtnBuilds = commitsBtwBuilds.Content.ReadAsStringAsync().Result;
                                                            CommitBetweenBuilds.Commits commits = JsonConvert.DeserializeObject<CommitBetweenBuilds.Commits>(commitsbtnBuilds);

                                                            LogData("changes in commit:" + commits.count);

                                                            if (commits.count == 0) // running for same commit id
                                                            {
                                                                string bRefURI = builds.value[b].uri;

                                                                buildResoureces.Add(bRefURI);
                                                                LogData("comparing builds for work items - commits 0");


                                                                // Get work items from the "FromBuildId"
                                                                _workItemConfiguration.API = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/builds/" + fromBuildId + "/workitems?api-version=" + _workItemConfiguration.APIVersion;
                                                                HttpResponseMessage _fromBuildWorkItemResponse = _workItem.GetWorkItemAssociatedToBuild(_workItemConfiguration, buildComplete.resource.definition.id); // Get work items associated to build

                                                                if (_fromBuildWorkItemResponse.IsSuccessStatusCode)
                                                                {
                                                                    string _wres = _fromBuildWorkItemResponse.Content.ReadAsStringAsync().Result;
                                                                    WorkItemslinkedToBuild.LinkedWITs _wlinkedWITs = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(_wres); // linked WITS
                                                                    // if there are work items
                                                                    if (_wlinkedWITs.count > 0)
                                                                    {
                                                                        LogData("work item count:" + _wlinkedWITs.count);
                                                                        isWorkItem = true;
                                                                        // if there is a work item linked to the incoming build
                                                                        LoopBuildResourceURL(buildResoureces, _wlinkedWITs);
                                                                    }
                                                                    else
                                                                    {
                                                                        _workItemConfiguration.API = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/builds/" + toBuildId + "/workitems?api-version=" + _workItemConfiguration.APIVersion;
                                                                        HttpResponseMessage _toBuildWorkItemResponse = _workItem.GetWorkItemAssociatedToBuild(_workItemConfiguration, buildComplete.resource.definition.id); // Get work items associated to build
                                                                        if (_toBuildWorkItemResponse.IsSuccessStatusCode)
                                                                        {
                                                                            string _wTores = _toBuildWorkItemResponse.Content.ReadAsStringAsync().Result;
                                                                            WorkItemslinkedToBuild.LinkedWITs _wTolinkedWITs = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(_wTores); // linked WITS
                                                                            if (_wTolinkedWITs.count > 0)
                                                                            {
                                                                                LogData("work item count:" + _wTolinkedWITs.count);
                                                                                isWorkItem = true;
                                                                                // if there is a work item linked to the incoming build
                                                                                LoopBuildResourceURL(buildResoureces, _wTolinkedWITs);
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                // Get compare the two build defs until it gets a work item
                                                                // Work item links will be from "fromBuildID"
                                                                // GET https://dev.azure.com/{organization}/{project}/_apis/build/workitems?fromBuildId={fromBuildId}&toBuildId={toBuildId}&api-version=5.1-preview.2
                                                                //string WITBetweenBuilds = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/workitems?fromBuildId=" + fromBuildId + "&toBuildId=" + toBuildId + "&api-version=5.1-preview.2";
                                                                //HttpResponseMessage buildCompare = _build.CompareBuilds(WITBetweenBuilds, _buildConfiguration);
                                                                //if (buildCompare.IsSuccessStatusCode)
                                                                //{
                                                                //    string bCompare = buildCompare.Content.ReadAsStringAsync().Result;
                                                                //    WorkItemslinkedToBuild.LinkedWITs linkedWI = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(bCompare);
                                                                //    if (linkedWI.count > 0)
                                                                //    {
                                                                //        LogData("linkedWI count:" + linkedWI.count);
                                                                //        isWorkItem = true;
                                                                //        // if there is a work item linked to the incoming build
                                                                //        LoopBuildResourceURL(buildResoureces, linkedWI);
                                                                //    }
                                                                //}
                                                                if (isWorkItem)
                                                                {
                                                                    break;
                                                                }
                                                            }
                                                            else if (commits.count > 0)
                                                            {
                                                                string bRefURI = builds.value[b].uri;
                                                                buildResoureces.Add(bRefURI);
                                                                LogData("comparing builds for work items - commits > 0");

                                                                _workItemConfiguration.API = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/builds/" + fromBuildId + "/workitems?api-version=" + _workItemConfiguration.APIVersion;
                                                                HttpResponseMessage _fromBuildWorkItemResponse = _workItem.GetWorkItemAssociatedToBuild(_workItemConfiguration, buildComplete.resource.definition.id); // Get work items associated to build

                                                                if (_fromBuildWorkItemResponse.IsSuccessStatusCode)
                                                                {
                                                                    string _wres = _fromBuildWorkItemResponse.Content.ReadAsStringAsync().Result;
                                                                    WorkItemslinkedToBuild.LinkedWITs _wlinkedWITs = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(_wres); // linked WITS
                                                                    // if there are work items
                                                                    if (_wlinkedWITs.count > 0)
                                                                    {
                                                                        LogData("work item count:" + _wlinkedWITs.count);
                                                                        isWorkItem = true;
                                                                        // if there is a work item linked to the incoming build
                                                                        //LoopBuildResourceURL(buildResoureces, _wlinkedWITs);
                                                                    }
                                                                }
                                                                break;

                                                                // Get compare the two build defs until it gets a work item
                                                                // Work item links will be from "fromBuildID"
                                                                // GET https://dev.azure.com/{organization}/{project}/_apis/build/workitems?fromBuildId={fromBuildId}&toBuildId={toBuildId}&api-version=5.1-preview.2
                                                                //string WITBetweenBuilds = _workItemConfiguration.BaseURL + _workItemConfiguration.ProjectName + "/_apis/build/workitems?fromBuildId=" + fromBuildId + "&toBuildId=" + toBuildId + "&api-version=5.1-preview.2";
                                                                //HttpResponseMessage buildCompare = _build.CompareBuilds(WITBetweenBuilds, _buildConfiguration);
                                                                //if (buildCompare.IsSuccessStatusCode)
                                                                //{
                                                                //    string bCompare = buildCompare.Content.ReadAsStringAsync().Result;
                                                                //    WorkItemslinkedToBuild.LinkedWITs linkedWI = JsonConvert.DeserializeObject<WorkItemslinkedToBuild.LinkedWITs>(bCompare);
                                                                //    if (linkedWI.count == 0)
                                                                //    {
                                                                //        break;
                                                                //    }
                                                                //    if (linkedWI.count > 0)
                                                                //    {
                                                                //        LogData("linkedWI count:" + linkedWI.count);
                                                                //        isWorkItem = true;
                                                                //        // if there is a work item linked to the incoming build
                                                                //        LoopBuildResourceURL(buildResoureces, linkedWI);
                                                                //    }
                                                                //}
                                                            }
                                                            if (isWorkItem)
                                                            {
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            string allbuild = allBuilds.ReasonPhrase + Environment.NewLine;
                                            LogData(allbuild);
                                        }
                                    }
                                }
                                else
                                {
                                    string res = workItemResponse.ReasonPhrase + Environment.NewLine;
                                    LogData(res);
                                }
                            }
                        }
                    }
                    LogData("Request: \n" + req);
                }
                else
                {
                    LogData("Request header is null, please provide required authorization parameters \n" + _Request.ToString());
                }
            }
            catch (Exception ex)
            {
                LogData(ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine + _Request.ToString());
            }
        }

        private void LoopBuildResourceURL(List<string> buildResoureces, WorkItemslinkedToBuild.LinkedWITs linkedWI)
        {
            foreach (var buildResrc in buildResoureces)
            {
                foreach (var wit in linkedWI.value)
                {
                    // Get the work item details with all relations
                    HttpResponseMessage _batchResponse = _workItem.GetWotkItemDetailInBatch(wit.url, _workItemConfiguration); // Getting WIT details in Batch
                    if (_batchResponse.IsSuccessStatusCode)
                    {
                        string batchres = _batchResponse.Content.ReadAsStringAsync().Result;
                        WorkItemResponse.WorkItem workItem = JsonConvert.DeserializeObject<WorkItemResponse.WorkItem>(batchres);
                        FormatUpdateWorkItem(buildResrc, workItem);
                    }
                    else
                    {
                        string batchres = _batchResponse.ReasonPhrase + Environment.NewLine;
                        LogData(batchres);
                    }
                }
            }
        }

        private HttpResponseMessage FormatUpdateWorkItem(string buildResourceURI, WorkItemResponse.WorkItem workItem)
        {
            try
            {
                if (workItem.relations.Count > 0) // if work item relation
                {
                    bool isLinkExist = false;
                    foreach (var _link in workItem.relations)
                    {
                        // for each relation, checking for relation matches the build resource uri
                        if (_link.url == buildResourceURI)
                        {
                            isLinkExist = true;
                        }
                    }
                    // if the URI is not exist, build a patch object and update the work item
                    if (!isLinkExist)
                    {
                        object[] patchObj = new object[1];
                        // forming patch request
                        patchObj[0] = new
                        {
                            op = "add",
                            path = "/relations/-",
                            value = new
                            {
                                rel = "ArtifactLink",
                                url = buildResourceURI,
                                attributes = new
                                {
                                    comment = "This build was linked by tool to this work item based on this work item's linked commits",
                                    name = "Integrated in build"
                                }
                            }
                        };
                        HttpResponseMessage updateResponse = _workItem.UpdateWorkItem(patchObj, _workItemConfiguration, workItem.fields.WorkItemId);
                        if (updateResponse.IsSuccessStatusCode)
                        {
                            LogData("Update workitem : " + workItem.fields.WorkItemId);
                            LogData(updateResponse.Content.ReadAsStringAsync().Result);
                            return updateResponse;
                        }
                        else
                        {
                            string updatedRes = updateResponse.ReasonPhrase + Environment.NewLine;
                            LogData(updatedRes);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogData(ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine);
            }
            return new HttpResponseMessage();
        }

        public void LogData(string logContent)
        {
            if (!Directory.Exists(logPath))
            {
                Directory.CreateDirectory(logPath);
            }
            File.AppendAllText(logFile, DateTime.Now.ToString("yyyy-MM-dd:HH:mm:ss") + "\t" + logContent + Environment.NewLine);
        }
    }
}
