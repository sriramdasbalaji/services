if(witCount > 0){

    take buildRefURI

    add BuildRefURIList = buildRefURI;

    witLinks = check for WorkItem Links

    if(witLinks > 0) {

        WitLink =  take the WIT Links
        batch =  get the work Items Details in batch(WitLink)
        Link (buildResourceURL,batch)
    }        
}
else {
    builds = Get all Builds();
    if(builds.count > 0){

        foreach(build) {
            b1
            b2
            commitsCount = check for change in commits btw b1 & b2

            if(commitsCount == 0){ // running for same commit Id

                take buildRefURI

                add BuildRefURIList = buildRefURI;

                witLinks = check for WorkItem Links between b2 & b1

                if(witLinks > 0) {

                    WitLink =  take the WIT Links
                    batch =  get the work Items Details in batch(WitLink)
                    pass BuildRefURI and WITlink(buildRefURI, batch) to link the Build
                    break;
                }
            }
            else if(commitsCount > 0) {

                take buildRefURI

                add BuildRefURIList = buildRefURI;

                witLinks = check for WorkItem Links btw b1 & b2

                if(witLinks == 0){
                    break;
                }
            }
        }
    }
}