﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace HttpRequestResponses
{
    public class HttpReqestResponse : IHttpRequestResponse
    {
        public HttpResponseMessage Get(string api, string authenticationType, string token)
        {
            //token = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", "", token)));
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authenticationType, token);
                HttpResponseMessage reqestResponse = client.GetAsync(api).Result;
                return reqestResponse;
            }
        }

        public HttpResponseMessage Patch(string api, object[] requestBody, string authenticationType, string token)
        {
            //token = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", "", token)));

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json-patch+json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authenticationType, token);

                var jsonContent = new StringContent(JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json-patch+json");
                var request = new HttpRequestMessage(new HttpMethod("PATCH"), api) { Content = jsonContent };

                HttpResponseMessage reqestResponse = client.SendAsync(request).Result;
                return reqestResponse;
            }
        }

        public HttpResponseMessage Post(string api, string requestBody, string authenticationType, string token)
        {
            //token = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", "", token)));

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authenticationType, token);

                var jsonContent = new StringContent(requestBody, Encoding.UTF8, "application/json");
                var request = new HttpRequestMessage(new HttpMethod("POST"), api) { Content = jsonContent };

                HttpResponseMessage reqestResponse = client.SendAsync(request).Result;
                return reqestResponse;
            }
        }

        public HttpResponseMessage Put(string api, string requestBody, string authenticationType, string token)
        {
            //token = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", "", token)));

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(authenticationType, token);

                var jsonContent = new StringContent(requestBody, Encoding.UTF8, "application/json");
                var request = new HttpRequestMessage(new HttpMethod("PUT"), api) { Content = jsonContent };

                HttpResponseMessage reqestResponse = client.SendAsync(request).Result;
                return reqestResponse;
            }
        }
    }
}
